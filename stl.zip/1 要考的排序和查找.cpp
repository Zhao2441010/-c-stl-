#include<iostream>
using namespace std;

// 注意,自写swap用引用
void swap(int&a,int &b){
    int t=a;
    a=b;
    b=t;
}

void maopao(int*a,int size){
    for(int i=0;i<size;i++){
        for(int j=i+1;j<size;j++){
            if(a[i]>a[j])swap(a[i],a[j]);
        }
    }
    for(int i=0;i<size;i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}

void xuanze(int*a,int size){
    for(int i=0;i<size;i++){
        int mn=a[i];
        int ind=i;
        for(int j=i;j<size;j++){
            if(a[j]<mn){
                mn=a[j];
                ind=j;
            }
        }
        swap(a[i],a[ind]);
    }
}

void insort(int*a,int size){
    for(int i=0;i<size;i++){
        int j=i-1;
        int sta=a[i];
        while(j>=0&&a[j]>sta){
            a[j+1]=a[j];
            j--;
        }
        // 放入位置
        a[j+1]=sta;
    }
    for(int i=0;i<size;i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}

void xier(int*a,int size){
    for(int k=size>>1;k>0;k>>=1){
    // k是距离,从大到小对下标 i+nk到i 插入排序
        for(int i=k;i<size;i++){
            int j=i-k;
            int sta=a[i];
            while(j>=0&&a[j]>sta){
            // 注意,j>=0
                a[j+k]=a[j];
                j-=k;
            }
            a[j+k]=sta;
        }
    }
    for(int i=0;i<size;i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}

void kp(int *a,int l,int r){
    int ll=l,rr=r;
    int sta=a[l];
    // 选基准
    while(ll<=rr){
        while(a[ll]<sta)ll++;
        while(a[rr]>sta)rr--;
        if(ll<=rr){
            swap(a[ll],a[rr]);
            ll++,rr--;
        }
    }
    // 越界判断
    if(ll<r)kp(a,ll,r);
    if(rr>l)kp(a,l,rr);
}

void heapify(int*a,int size,int i){
    int mx=i;
    // 假设最大值就是i
    int l=2*i+1;
    int r=2*i+2;
    // 与子树比较更新
// 注意判断越界
    if(l<size&&a[mx]<a[l])mx=l;
    if(r<size&&a[mx]<a[r])mx=r;

    if(mx!=i){
        swap(a[mx],a[i]);
        heapify(a,size,mx);
    }

}
//完全二叉树最后一个非叶子节点是(n-2)/2 
// 建树从最后一个叶子节点去建树
void buildheap(int*a,int size){
    for(int i=(size-2)/2;i>=0;i--){
        heapify(a,size,i);
    }
}
// 转换顺序
void heapsort(int*a,int size){
    buildheap(a,size);
    for(int i=size-1;i>0;i--){
        swap(a[i],a[0]);
        heapify(a,i,0);
    }
}


// 分块为l到mid mid+1到r 
void merge(int arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    // 创建临时数组
    int L[n1], R[n2];

    // 复制数据到临时数组
    for (int i = 0; i < n1; i++) {
        L[i] = arr[left + i];
    }
    for (int j = 0; j < n2; j++) {
        R[j] = arr[mid + 1 + j];
    }

    // 合并临时数组到原数组
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    // 拷贝剩余的元素（如果有的话）
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void mergeSort(int arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2; // 防止溢出

        // 递归排序左右两部分
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);

        // 合并排序好的两部分
        merge(arr, left, mid, right);
    }
}


signed main(){
    int a[12]={2,9,5,6,2,1,4,47,7,6,-1,-2};
    int num=12;
    // for(int i=0;i<num;i++){
    //     cout<<a[i]<<" ";
    // }

    // maopao(a,num);

    // kp(a,0,num-1);
    // for(int i=0;i<num;i++){
    //     cout<<a[i]<<" ";
    // }

    // insort(a,num);

    // xier(a,num);
        // k从大到小
        // 每次从0+nk到0对 0,0+k,0+2k 进行插入排序

    // xuanze(a,num);

    // heapsort(a,num);
    // for(int i=0;i<num;i++){
    //     cout<<a[i]<<" ";
    // }cout<<endl;

    mergeSort(a,0,num-1);
    for(int i=0;i<num;i++){
        cout<<a[i]<<" ";
    }
}