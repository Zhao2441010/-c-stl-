#include <iostream>
using namespace std;

class cvec{
public:
    int size=0;
    int *val=nullptr;
    int mxsize=1;

    cvec(){
        val=new int[mxsize];
    }
    ~cvec(){
        delete[]val;
    }

    void push_back(int x){
        if(size==mxsize){
            resize();
        }
        val[size++]=x;
    }

    void pop_back(){
        if(size>0)size--;
    }

    void resize(){
        int *nt=new int[2*mxsize];
        mxsize=2*mxsize;
        for(int i=0;i<size;i++){
            nt[i]=val[i];
        }
        delete[]val;
        val=nt;
    }

    int&operator[](int i){
        return val[i];
    }

};




int main(){
    //考试用版本只实现了push_back和pop_back

    //如果需要复制,新建,再去调用push_back
}