#include <iostream>
using namespace std;

// 层序建树
// struct node{
//     char val;
//     int l=-1,r=-1;
//     int from=-1;
// }tree[200];
// int num=0;
// void dfs(int i){
//     if(i==-1)return;
//     if(tree[i].val=='n')return;

//     if(tree[tree[i].l].val!='n')dfs(tree[i].l);

//     if(tree[tree[i].r].val!='n')dfs(tree[i].r);
//     cout<<tree[i].val<<" ";
// }
// signed main(){
// ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//     string cengxu;
//     cin>>cengxu;
//     //层序遍历满足是完全二叉树
//     //第i的l是2*i,r是2*i+1
//     cengxu=" "+cengxu;
//     for(int i=1;i<cengxu.size();i++){
//         tree[i].val=cengxu[i];
//         //先创建节点再去链接
//     }
//     int i=1,now=1;
//     //i是进行到的位置
//     //now是要去添加子节点的
//     while(i*2+1<cengxu.size()){
//         while(tree[now].val=='n')now++;
//         //如果进行的是空,那么要跳过
//         //必须加到非末尾节点
//         tree[now].l=2*i;
//         tree[now].r=2*i+1;
//         i++;
//         now++;
//     }
//     dfs(1);
// }




// 先中建树
// string zhong,hou;
// int zi[26+9];
// struct{
//     char val=' ';
//     int l=-1,r=-1;
// }node[39];
// int num=0;
// int build(int zs,int ze,int tar){
//     if(zs>ze)return -1;
//     int ind=num++;
//     node[ind].val=hou[tar];
//     node[ind].l=build(zs,zi[hou[tar]-'a']-1,tar-(ze-zi[hou[tar]-'a'])-1);
// //注意这里,目标位置是当前-1-右子树个数
//     node[ind].r=build(zi[hou[tar]-'a']+1,ze,tar-1);
//     return ind;
// }
// void dfs_x(int x){
//     cout<<node[x].val;
//     if(node[x].l!=-1)dfs_x(node[x].l);
//     if(node[x].r!=-1)dfs_x(node[x].r);
// }
// signed main(){
// ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
// 	cin>>zhong>>hou;
//     int n=zhong.size();
//     for(int i=0;i<n;i++){
//         zi[zhong[i]-'a']=i;
//     }
// 	build(0,n-1,n-1);
//     dfs_x(0);
// }


int main(){

    
}