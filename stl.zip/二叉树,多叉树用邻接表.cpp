#include <bits/stdc++.h>
using namespace std;

template <class T>
struct Node {
    T val;
    int from = -1;
    int l_id = -1, r_id = -1;
    Node(const T& va) : val(va) {}
    Node() : val(T()) {}
    Node operator=(const Node& b) {
        val = b.val;
        from = b.from;
        l_id = b.l_id;
        r_id = b.r_id;
        return *this;
    }
};
template <class T>
class tree {
public:
    int size = 0;
    int mxsize = 100;
    Node<T>* val = nullptr;

    tree(const T& va) {
        val = new Node<T>[mxsize];
        val[0].val = va;
        size = 1;
    }

    ~tree() { delete[] val; }

    void insert(int p_id, const Node<T>& b) {
        if (size >= mxsize) {
            rsize();
        }
        val[size] = b;
        if (val[p_id].l_id == -1) {
            val[p_id].l_id = size;
        } else if (val[p_id].r_id == -1) {
            val[p_id].r_id = size;
        } else {
            cout << p_id << " full" << endl;
        }
        size++;
    }

    void show() {
        queue<int> q;
        q.push(0);
        while (!q.empty()) {
            int size = q.size();
            while (size--) {
                int now = q.front();
                q.pop();
                cout << val[now].val << " ";
                if (val[now].l_id != -1) q.push(val[now].l_id);
                if (val[now].r_id != -1) q.push(val[now].r_id);
            }
            cout << endl;
        }
    }

    void rsize() {
        Node<T>* nv = new Node<T>[2 * mxsize];
        for (int i = 0; i < size; i++) {
            nv[i] = val[i];
        }
        delete[] val;
        val = nv;
        mxsize *= 2;
    }
};

signed main() {
    ios::sync_with_stdio(0), cin.tie(0);
    tree<int> tr(2);
    tr.insert(0, Node<int>(2));
    tr.insert(0, Node<int>(3));
    tr.insert(1, Node<int>(4));
    tr.insert(1, Node<int>(5));
    tr.show();
    return 0;
}