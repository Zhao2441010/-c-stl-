#include<iostream>
using namespace std;

class cque{
public:
    int size=0;
    int l=0,r=0;
    int mxsize=10000;
    int*val=nullptr;

    cque(){
        val=new int[mxsize];
    }

    void push(int x){
        if(r==mxsize-1)resize();
        r=size;
        val[size++]=x;
    }
    void pop(){
        if(size){
            size--;
            l++;
        }
    }
    int front(){
        if(size)return val[l];
    }

    void resize(){
        mxsize=2*mxsize;
        int *nv=new int[mxsize];
        int num=0;
        for(int i=l;i<=r;i++){
            nv[num++]=val[i];
        }
        delete[] val;
        val=nv;
        l=0;
        r=num-1;
        size=num;
    }

    ~cque(){
        delete[]val;
    }

};


signed main(){
    
}