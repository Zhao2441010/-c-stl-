#include <iostream>
using namespace std;
class cstack{
public:
    int *val=nullptr;
    int mxsize=10000;
    int size=0;

    cstack(){
        val=new int[mxsize];
    }
    ~cstack(){
        delete []val;
    }
    void push(int x){
        if(size==mxsize)resize();
        val[size++]=x;
    }

    void pop(){
        if(size>0)size--;
    }

    int& top(){
        if(size>0)return val[size-1];
    }

    void resize(){
        mxsize=2*mxsize;
        int*nv=new int[mxsize];
        for(int i=0;i<size;i++){
            nv[i]=val[i];
        }
        delete[]val;
        val=nv;
    }
};

int main(){

    
}