#include<iostream>
using namespace std;




// 内容说明:
    // 求可达性,一般把vec[i][j]设置为0,1表示可达与不可达
    
    // 求路径权值(距离,时间),可达将vec[i][j]设置为对应权值
                        // 不可达设为1e9

    // 有向图和无向图
        // 有向图一对点互相可达,所以vec[i][j]=vec[j][i]

        // 无向图只能单向到达,所以只有vec[from][to]



// 图的存储:邻接表 邻接矩阵
const int N=/*点的数量*/ +9;

// 邻接矩阵
int vec[N][N];
// vec[i][j]存储i到j的可达关系或权值
    // int s,e,val
    // cin>>s>>e>>val;
    //无向图输入时vec[s][e]=vec[e][s]=val
    // 有向图vec[s][e]=val 

// 邻接表
// 在邻接矩阵的基础上加上辅助数组
int num[N];//size[i]记录i有size[i]个可以到达点
int to[N][N];//to[i][0~size[i]-1]记录可到达点的序号

// 举例说明:    
// i可以到j和k    i到j距离为20    到k距离15

// 邻接矩阵
// vec[i][j]=20,vec[i][j]=15  其他vec[i][t]为1e9表示不可达

// 邻接表
// size[i]=2    i可以到两个点
// to[i][0]=j  to[i][1]=k  记录两个到达点

int main(){

// 直接输入邻接矩阵 理论9第一题(可达性) 实验五第三题(权值)
    /*
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            cin>>vec[i][j];
        }
    }
    */

// 输入点之间的关系 理论9第二题
    /*
    // 互相认识,是无向图
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int s,e;
        cin>>s>>e;
        vec[s][e]=vec[e][s]=1;
        
        to[s][num[s]++]=e;
        to[e][num[e]++]=s;
    }
    */

// 输入图形 理论9第三题
    /*
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            char t;
            cin>>t;
            if(t=='*')vec[i][j]=0;
                //*表示没有石油设为0 
            else vec[i][j]=1;
                // @表示有设为1
        }
    }
    */

// 输入起点终点 实验五第一题,第四题
    /*
    int n,m;
    cin>>n>>m;
    while(m--){
        int s,e,val;
        cin>>s>>e>>val;
        // 无向图
            // vec[s][e]=val;
            // vec[e][s]=val;
        
        // 有向图
            // vec[s][e]=val;
    }
    */
}