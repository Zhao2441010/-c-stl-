#include<iostream>
#include<queue>
using namespace std;

// dfs沿着一条分支遍历到没有下一分支结束
// bfs每次把当前节点同一层次的遍历并且把下一层次入队

// dfs和bfs都可以把联通的全部遍历
    // 所以对每个点去dfs/bfs,
    // 如果已经用过了(used数组记录)就下一个点,
    // 如果没用,那么分支数+1
class cque {
public:
    int size = 0; // 当前队列中的元素个数
    int l = 0;    // 队列头部在数组中的索引
    int mxsize = 10000; // 队列容量
    int* val = nullptr; // 存储数据的数组

    cque() {
        val = new int[mxsize];
    }

    void push(int x) {
        if (size == mxsize) { // 队列已满，需要扩容
            resize();
        }
        int pos = l + size;   // 新元素应该存放的位置
        if (pos >= mxsize) {  // 如果超出数组边界，压缩数据到前面
            for (int i = 0; i < size; i++) {
                val[i] = val[l + i];
            }
            l = 0;      // 压缩后头部重置为0
            pos = size; // 新元素放在size位置
        }
        val[pos] = x;
        size++;
    }

    void pop() {
        if (size) {
            l++;     // 头部索引后移
            size--;  // 元素数量减少
        }
    }

    int front() {
        if (size) {
            return val[l]; // 返回头部元素
        }
        return -1; // 空队列返回-1
    }

    // 扩容队列
    void resize() {
        int new_mxsize = mxsize * 2;
        int* new_val = new int[new_mxsize];
        // 将有效数据复制到新数组前面
        for (int i = 0; i < size; i++) {
            new_val[i] = val[l + i];
        }
        delete[] val;
        val = new_val;
        mxsize = new_mxsize;
        l = 0; // 头部重置为0
    }

    ~cque() {
        delete[] val;
    }
};


const int N= /*点的数量*/2000+9;
int vec[N][N];

int num[N];
int to[N][N];
bool used[N];

void dfs(int root){
    used[root]=1;
    
    //邻接表款 
    for(int i=0;i<num[root];i++){
        if(used[to[root][i]])continue;
        dfs(to[root][i]);
    }

    // // 邻接矩阵款
    // for(int i=1;i<=n;i++){
    //     //n是全局变量
    //     if(vec[root][i]&&!used[i]){
    //         dfs(i);
    //     }
    // }
    
}
void bfs(int root){
    cque q;
    q.push(root);
    used[root]=1;
    while(q.size){
        auto t=q.front();
        q.pop();
        for(int i=0;i<num[t];i++){
            if(!used[to[t][i]]){
                q.push(to[t][i]);
                used[to[t][i]]=1;
            }
        }
    }
}

void bfs_c(int root){
    // 层序遍历利用每次q的size是本层成员总数
    // 实现分层输出
    cque q;
    q.push(root);
    used[root]=1;
    
    while(q.size){
        int size=q.size;
        while(size--){
            auto t=q.front();
            used[t]=1;
            q.pop();
cout<<t<<" ";
            for(int i=0;i<num[t];i++){
                if(!used[to[t][i]]){
                    q.push(to[t][i]);
                    used[to[t][i]]=1;
                }
            }
        }
cout<<endl;
    }

}
int main(){
    int n,m;
    cin>>n>>m;

    while(m--){
        int s,e;
        cin>>s>>e;
        vec[s][e]=vec[e][s]=1;
        // 邻接表操作
        to[s][num[s]++]=e;
        to[e][num[e]++]=s;
    }

    int ans=0;


    for(int i=1;i<=n;i++){
        if(used[i])continue;
        // dfs(i);
        bfs(i);
        ans++;
        // bfs_c(i);
    }

    

    cout<<ans<<endl;

}