#include<bits/stdc++.h>
using namespace std;

const int N=/*点数*/1e3+9;
int vec[N][N];
int num[N];
int to[N][N];

int ans[N];
bool used[N];
int n,m;

int  min(int a,int b){
    if(a<b)return a;
    return b;
}


void djstra(int root){
    for(int i=1;i<=n;i++){
        ans[i]=vec[root][i];
    }
    for(int k=1;k<=n;k++){
        
        int ind=-1,val=1e9;
        for(int i=1;i<=n;i++){
            if(!used[i]&&ans[i]<val){
                ind=i;
                val=ans[i];
            }
        }

        if(ind==-1)return ;

        used[ind]=1;
        
        for(int i=0;i<num[ind];i++){
            int t=to[ind][i];
            if(vec[ind][t]!=1e9){
                ans[t]=min(ans[t],ans[ind]+vec[ind][t]);
            }
        }
    }
    
}


signed main(){


    cin>>n>>m;
    int root;
    cin>>root;

    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(i!=j)vec[i][j]=1e9;
        }
    }

    while(m--){
        int s,e,val;
        cin>>s>>e>>val;
        vec[s][e]=val;
        to[s][num[s]++]=e;
        // vec[e][num[e]++]=s;
    }
    
    djstra(root);

    for(int i=1;i<=n;i++){
        cout<<ans[i]<<" ";
    }
}