#include<iostream>
using namespace std;
const int N=2e5+9;


struct edge{
    int l,r,val;
}e[N];

void swap(edge&a,edge&b){
    edge t=a;
    a=b;
    b=t;
}

int bc[N];
int find(int x){
    if(x==bc[x])return x;
    return bc[x]=find(bc[x]);
}

int n,m;

signed main(){
    cin>>n>>m;

    for(int i=1;i<=n;i++){
        bc[i]=i;
    }

    for(int i=1;i<=m;i++){
        cin>>e[i].l>>e[i].r>>e[i].val;
    }

    for(int i=1;i<=m;i++){
        for(int j=1;j<=m;j++){
            if(e[i].val<e[j].val){
                swap(e[i],e[j]);
            }
        }
    }

    int num=0;
    int ans=0;
    for(int i=1;i<=m;i++){
        int ll=find(e[i].l);
        int rr=find(e[i].r);

        if(ll==rr)continue;
cout<<e[i].l<<" "<<e[i].r<<endl;
        bc[ll]=rr;
        ans=ans+e[i].val;
        num++;
        if(num==n-1)break;
    }
    if(num==n-1)cout<<ans<<endl;
    else cout<<"orz"<<endl;

}