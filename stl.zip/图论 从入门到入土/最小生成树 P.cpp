#include<iostream>
using namespace std;

const int N=1e4+9;

int vec[N][N];
int num[N];
int to[N][N];

int n,m;

int ans=0,cnt=0;
int cost[N];
bool used[N];

void prim(int root=1){
    for(int i=1;i<=n;i++){
        cost[i]=vec[root][i];
    }

    for(int k=1;k<=n;k++){
        int ind=-1;
        int val=1e9;

        for(int i=1;i<=n;i++){
            if(!used[i]&&cost[i]<val){
                val=cost[i];
                ind=i;
            }
        }

        if(ind==-1)break;

        used[ind]=1;
        cnt++;
        ans=ans+cost[ind];

        for(int i=0;i<num[ind];i++){
            int t=to[ind][i];
            if(vec[ind][t]!=1e9){
                cost[t]=min(cost[t],vec[ind][t]);
            }
        }
    }
}



signed main(){
    cin>>n>>m;

    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(i!=j)vec[i][j]=1e9;
        }
    }

    for(int i=1;i<=m;i++){
        int s,e,val;
        cin>>s>>e>>val;
        vec[s][e]=vec[e][s]=val;
        to[s][num[s]++]=e;
        to[e][num[e]++]=s;
    }

    prim();

    if(cnt==n)cout<<ans<<endl;
    else cout<<"orz";

}