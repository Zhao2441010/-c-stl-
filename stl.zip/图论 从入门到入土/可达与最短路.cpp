#include<iostream>
using namespace std;
class cque {
public:
    int size = 0; // 当前队列中的元素个数
    int l = 0;    // 队列头部在数组中的索引
    int mxsize = 10000; // 队列容量
    int* val = nullptr; // 存储数据的数组

    cque() {
        val = new int[mxsize];
    }

    void push(int x) {
        if (size == mxsize) { // 队列已满，需要扩容
            resize();
        }
        int pos = l + size;   // 新元素应该存放的位置
        if (pos >= mxsize) {  // 如果超出数组边界，压缩数据到前面
            for (int i = 0; i < size; i++) {
                val[i] = val[l + i];
            }
            l = 0;      // 压缩后头部重置为0
            pos = size; // 新元素放在size位置
        }
        val[pos] = x;
        size++;
    }

    void pop() {
        if (size) {
            l++;     // 头部索引后移
            size--;  // 元素数量减少
        }
    }

    int front() {
        if (size) {
            return val[l]; // 返回头部元素
        }
        return -1; // 空队列返回-1
    }

    // 扩容队列
    void resize() {
        int new_mxsize = mxsize * 2;
        int* new_val = new int[new_mxsize];
        // 将有效数据复制到新数组前面
        for (int i = 0; i < size; i++) {
            new_val[i] = val[l + i];
        }
        delete[] val;
        val = new_val;
        mxsize = new_mxsize;
        l = 0; // 头部重置为0
    }

    ~cque() {
        delete[] val;
    }
};



const int N=1e3+9;
int vec[N][N];
int num[N];
int to[N][N];
int n,m;


//floyd算法
//对于起点i，终点j，如果有k，vec[i][k]=vec[k][j]=1
//那么称ij可达

void floyd(){//可达性
    for(int k=1;k<=n;k++){
// k在最外层
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                if(vec[i][k]!=0&&vec[k][j]!=0){
                    vec[i][j]=1;
                }
            }
        }
    }
}



// 全源最短路径
void floyd_val(){//最小代价
//初始化均为1e9，之后正常读取s，e，val
    for(int k=1;k<=n;k++){
// k在最外层
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                if(vec[i][k]!=1e9&&vec[k][j]!=1e9){
                    vec[i][j]=min(vec[i][j],vec[i][k]+vec[k][j]);
                }
            }
        }
    }
}





int main()
{
    cin>>n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            cin>>vec[i][j];
        }
    }
    floyd();
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            cout<<vec[i][j]<<" ";
        }cout<<endl;
    }
    
    return 0;
}