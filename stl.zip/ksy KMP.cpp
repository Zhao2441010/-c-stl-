#include<iostream>
#include<cstring>
using namespace std;



void kmp(char*da,char*xiao,int *ans,int &asize){
    int dsize=strlen(da);
    int xsize=strlen(xiao);
    asize=0;
    // 这里一定要初始化为0

    int next[xsize];
    for(int i=0;i<xsize;i++){
        next[i]=0;
    }
    int t=0,now=0;
    
    t=0;
    for(int i=1;i<xsize;){
        if(xiao[i]==xiao[t]){
            t++;
            next[i]=t;
            i++;
        }else if(t>0){
            t=next[t-1];
        }
        else{
            next[i]=0;
            t=0;
            i++;
        }
    }

    now=0,t=0;
    // 一定要初始化为0

    while(now<dsize){
        if(da[now]==xiao[t]){
            now++,t++;
        }else{
            if(t!=0)t=next[t-1];
            else{
                now++;
            }
        }
        if(t==xsize){
            ans[asize++]=now-t;
            now=now-t+1;
            // ans数组记录的是下标
        }
    }
}

int main(){
    char da[1000];
    char xiao[1000];
    
    cin>>da>>xiao;
    
    int ans[1000];
    int asize=0;

    kmp(da,xiao,ans,asize);
    // ans数组记录的是下标
    for(int i=0;i<asize;i++){
        cout<<ans[i]<<" ";
    }
}