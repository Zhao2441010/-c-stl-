class cque {
public:
    int size = 0; // 当前队列中的元素个数
    int l = 0;    // 队列头部在数组中的索引
    int mxsize = 10000; // 队列容量
    int* val = nullptr; // 存储数据的数组

    cque() {
        val = new int[mxsize];
    }

    void push(int x) {
        if (size == mxsize) { // 队列已满，需要扩容
            resize();
        }
        int pos = l + size;   // 新元素应该存放的位置
        if (pos >= mxsize) {  // 如果超出数组边界，压缩数据到前面
            for (int i = 0; i < size; i++) {
                val[i] = val[l + i];
            }
            l = 0;      // 压缩后头部重置为0
            pos = size; // 新元素放在size位置
        }
        val[pos] = x;
        size++;
    }

    void pop() {
        if (size) {
            l++;     // 头部索引后移
            size--;  // 元素数量减少
        }
    }

    int front() {
        if (size) {
            return val[l]; // 返回头部元素
        }
        return -1; // 空队列返回-1
    }

    // 扩容队列
    void resize() {
        int new_mxsize = mxsize * 2;
        int* new_val = new int[new_mxsize];
        // 将有效数据复制到新数组前面
        for (int i = 0; i < size; i++) {
            new_val[i] = val[l + i];
        }
        delete[] val;
        val = new_val;
        mxsize = new_mxsize;
        l = 0; // 头部重置为0
    }

    ~cque() {
        delete[] val;
    }
};
