#include<iostream>
#include<cstring>
using namespace std;

const int N=2e4+9;
// N=2*n-1

struct Node{
    char pre;

    int val;
    int rotnum=0;
    int l=-1,r=-1;
    char code[100];
}no[N];

int tot,r;
bool used[N];
int have[N];

void swap(Node a,Node b){
    Node t=a;
    a=b;
    b=t;
}


void dfs(int root,char*s){
    strcpy(no[root].code,s);
    if(no[root].l!=-1){
        char t[200];
        strcpy(t,s);
        strcat(t,"0");
        dfs(no[root].l,t);
    }if(no[root].r!=-1){
        char t[200];
        strcpy(t,s);
        strcat(t,"1");
        dfs(no[root].r,t);
    }
}

int main(){
    int n;
    cin>>n;

    for(int i=1;i<=n;i++){
    //在这里修改输入,实现数字与字母的节点建立
        char t;
        cin>>t;
        have[t-'a']++;
    }

    for(int i=0;i<26;i++){
        if(have[i]){
            no[++r].pre='a'+i;
            no[r].val=have[i];
        }
    }
    
    int num=r;
    tot=r;

    while(num>1){
        int w1,w2;

        int ind=-1;
        int val=1e9;
        int rootnum=0;

        for(int i=1;i<=r;i++){
            if(!used[i]){
                if((no[i].val<val)||(no[i].val==val&&rootnum>no[i].rotnum)){
                    val=no[i].val;
                    ind=i;
                    rootnum=no[i].rotnum;
                }
            }
        }

        if(ind==-1)break;

        used[ind]=1;
        
        w1=ind;

        ind=-1;
        val=1e9;
        rootnum=0;

        for(int i=1;i<=r;i++){
            if(!used[i]){
                if((no[i].val<val)||(no[i].val==val&&rootnum>no[i].rotnum)){
                    val=no[i].val;
                    ind=i;
                    rootnum=no[i].rotnum;
                }
            }
        }

        if(ind==-1)break;

        used[ind]=1;

        w2=ind;

        no[++r].val=no[w1].val+no[w2].val;
        no[r].rotnum=no[w1].rotnum+no[w2].rotnum;
        if(no[w1].val<no[w2].val){
            no[r].l=w1;
            no[r].r=w2;
            
        }else{
            no[r].l=w2;
            no[r].r=w1;
        }
        num--;
    }
    char a[2000]="";
    dfs(r,a);
    for(int i=1;i<=tot;i++){
        cout<<no[i].pre<<" "<<no[i].code<<endl;
    }
}